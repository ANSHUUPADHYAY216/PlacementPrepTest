package Test1;

import java.util.Scanner;

public class Quest3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int x= sc.nextInt();
		sc.close();
		String s= Integer.toString(x);
		int i=0;
		int j=s.length()-1;
		boolean pali=true;
		while(i<j)
		{
			if(s.charAt(i)==s.charAt(j)) {
				i++;
				j--;
				pali=true;
			}
			else
			{
				pali=false;
				break;
			}
		}
		System.out.println(pali);
	}

}
