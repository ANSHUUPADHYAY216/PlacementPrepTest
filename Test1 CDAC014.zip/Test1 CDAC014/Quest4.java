package Test1;

import java.util.Scanner;

public class Quest4 {
	public static void main(String[] args) {
		int m=0;
		int n=1;
		int b=m+n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		int x=sc.nextInt();
		sc.close();
		if(x==0) {
			System.out.print(m+" ");
		}
		else if(x==1)
		{
			System.out.println(m+"  "+n);
		}
		else
		{
			for(int i =0;i<x;i++)
			{
				System.out.print(m+"   ");
				m=n;
				n=b;
				b=m+n;
			}
		}
	}
}