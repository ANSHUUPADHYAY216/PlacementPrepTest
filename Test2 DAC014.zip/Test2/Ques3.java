package Test2;
public class Ques3 {
	public static void main(String[] args) {
		int n = 3;
	    for(int i = 1; i <= n; i++)
	    {
	    	for(int j=n-1;j>=i;j--)
	    	{
	    		System.out.print(" ");
	        }
	        for(int k=i;k>=1;k--)
	        {
	            System.out.print(k);
	        }
	        for (int k = 2; k <= i; k++)
	        {
	            System.out.print(k);
	        }
	     System.out.println();
	     }
	     for(int i=n-1;i>=1;i--)
	     {
	    	 for(int j=n-1;j>=i;j--)
	    	 {
	             System.out.print(" ");
	         }
	         for(int k=i;k>=1;k--)
	         {
	             System.out.print(k);
	         }

	         for(int k = 2;k<=i;k++) 
	         {
	            System.out.print(k);
	         }
	            System.out.println();
	        }
//	    --3
//	    -323
//		32123
//	    -323
//	    --3
		for(int i=3;i>0;i--)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}