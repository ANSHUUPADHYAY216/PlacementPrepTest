package Test2;

import java.util.Scanner;

public class Ques1 {
	public static int fac(int x)
	{
		int fact;
		if(x==1||x==0) {
			return 1;
		}
		else
		{
			fact=x*fac(x-1);
		}
		return fact;
	}
	public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the Number:");
	int x =sc.nextInt();
	sc.close();
	System.out.println(fac(x));
	}	
}
