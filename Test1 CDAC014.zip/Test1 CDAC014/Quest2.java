package Test1;

import java.util.Scanner;

public class Quest2 {
	public static void main(String []args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter start and end:  ");
		int start= sc.nextInt();
		int end = sc.nextInt();
		sc.close();
//		for(int i=start;i<end;i++)
//		{
//			if(i%2!=0)
//			{
//				System.out.print(i+"   ");
//			}
//		}
		if(start%2==0)
		{
			start++;
		}
		while(start<end)
		{
			System.out.print(start+"  ");
			start=start+2;
		}
	}
}
