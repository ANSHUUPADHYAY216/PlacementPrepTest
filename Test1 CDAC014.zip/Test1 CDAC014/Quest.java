package Test1;

import java.util.Scanner;

public class Quest {
	public static void main(String[] args) {
		System.out.println("Enter the Number");
		Scanner sc= new Scanner(System.in);
		int x=sc.nextInt();
		sc.close();
//		if(x%3==0 && x%7==0) {
//			System.out.println("fun Buzz");
//		}
//		else if(x%3==0) {
//			System.out.print("fun ");
//		}
//		else if(x%7==0)
//		{
//			System.out.println(" Buzz");
//		}
//		
		if(x%3==0) {
			System.out.print("fun ");
		}
		if(x%7==0)
		{
			System.out.println(" Buzz");
		}
	}
}