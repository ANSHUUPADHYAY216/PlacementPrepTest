package Test2;

public class Ques4 {
public static void revbin(int x)
{
	int y=x%2;
	System.out.print(y);
	if(x==0)
	{
		return;
	}
	else {
	revbin(x/2);
	}
}
	public static void main(String[] args) {
		int x=4;
		revbin(x);
	}

}
