package Test2;
public class Ques2 {

	public static void main(String[] args) {
		
	}
}
